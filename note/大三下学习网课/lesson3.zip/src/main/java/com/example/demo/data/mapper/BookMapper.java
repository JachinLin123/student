package com.example.demo.data.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.data.domain.Book;

/**
 * Created by litdwg on 2020/3/3 16:43
 */
public interface BookMapper extends BaseMapper<Book> {
}
